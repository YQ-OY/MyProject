package com.wangchai.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeptCountVo {

    private Long deptCount;    // 部门数量
//    private Double deptRate;     // 部门增长率

}
