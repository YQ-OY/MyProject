package com.wangchai.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.wangchai.domain.entity.UserInfo;

public interface UserInfoMapper extends BaseMapper<UserInfo> {
}
