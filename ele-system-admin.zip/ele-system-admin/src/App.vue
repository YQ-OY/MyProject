<script setup></script>

<template>
  <router-view></router-view>
</template>

<style>

  #app{
    width:100%;
    height:100%;
    /* 隐藏超出的部分，且不会生成滚动条 */
    overflow: hidden; 
  }

</style>
